#include<stdio.h>
#include <stdlib.h>
#include <signal.h>


void sig_handler(int signum){
	printf("\n Received signal %d\n", signum);
	printf("Are you sure you want to exit(Y/N)?");
	char ch; scanf("%c", &ch);
	if(ch=='Y')
	{
		exit(0);
	}
	else{
	}
}

void sig_fun(int signum){
	printf("\n Received signal %d\n", signum);
        printf("Are you sure you want to exit?");

	char ch; scanf("%c", &ch);
        if(ch=='Y')
        {
                exit(0);
        }
        else{
        }

}
int main()

	{
	    signal(SIGINT, sig_handler);
	    signal(SIGTERM, sig_fun);
	    while(1)
	    sleep(10);
	    return 0;
	}
