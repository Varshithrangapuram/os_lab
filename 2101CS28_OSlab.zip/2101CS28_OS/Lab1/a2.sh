#!/bin/bash

echo Enter first number: 
read n1
echo Enter second number:
read n2

str=""
while [ $n1 -le $n2 ]
do
    str+="$n1 "
    let n1++
done
echo $str
