#!/bin/bash

echo Enter your filepath:
read fp

echo Enter your filename pattern:
read fpatern

echo Enter your new filename:
read newf

res= $(find $fp -name $fpatern)

for fil in $res
do
   mv $fil $newf
done


