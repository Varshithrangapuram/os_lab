#!/bin/bash

echo "Hi what is your name?"

read name
echo "Hi $name welcome to os  lab"

echo "Enter your age"
read age

if [ $age  -ge 18 ] ; then
echo  "You are above 18"
else
echo "You are below 18"
fi

filename="/home/student/2101CS28_OS/path.txt"

for item in $(cat $filename)
do
    echo  Core courses of cse are $item
done



