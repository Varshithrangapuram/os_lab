#!/bin/bash

echo Enter file name:
read fil

echo Enter min no of lines:
read n

echo Number of lines in file are:
wc -l< $fil
res=$(< "$fil" wc -l)

if [ $res -lt $n ]; then
echo File deleted.
rm $fil
fi

