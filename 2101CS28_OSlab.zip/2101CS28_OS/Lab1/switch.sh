#!bin/bash

echo "enter a option"
echo enter 1 for date
echo enter 2 for folder contents
echo enter 3 for 
