#include<stdio.h>
#include<unistd.h>

int main()
{
pid_t id;
id=fork();

if(id<0)
printf("Unable to fork.");

else if(id==0){
printf("My process id is %d\n", getpid());
printf("The parent process id is: %d\n", getppid());
}

else{
printf("My process id is: %d\n", getpid());
printf("My child process id is: %d\n",id);
}

return 0;
}
