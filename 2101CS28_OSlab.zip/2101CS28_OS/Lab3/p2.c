#include<stdio.h>
#include<unistd.h>

int main()
{
pid_t id;
id=fork();

if(id<0)
printf("Unable to fork.");

else if(id==0){
printf("My process id is %d\n", getpid());
printf("The parent process id is: %d\n\n", getppid());
}

else{
wait();
printf("My process id is: %d\n", getpid());
printf("My child process id is: %d\n",id);
printf("The child with process id %d is terminated.\n", id);
}

return 0;
}
