#include<stdio.h>
#include<unistd.h>
#include<stdlib.h>
#include<string.h>
#include<fcntl.h>

int main(int argc, char* argv[])
{

const char *fname= argv[1];
int filed= open(fname,  O_WRONLY|O_CREAT|O_TRUNC, S_IWUSR| S_IRUSR);

if(filed==-1){
perror("Unable to open.");
return 1;
}

pid_t child_id= fork();

if(child_id==-1){
  printf("NOt forked");
return 1;
}

else if(child_id==0){
  const char* msg= "hello world i am the child\n";
  write(filed,msg, strlen(msg)); 
  exit(0);
}

else{
  wait();
  const char* msg= "hello world i am the parent\n";
  write(filed,msg, strlen(msg)); 

}
return 0;
}
