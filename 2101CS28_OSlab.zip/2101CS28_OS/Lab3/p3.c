#include<stdio.h>
#include<unistd.h>

int main()
{
pid_t id;
id=fork();

if(id<0)
printf("Unable to fork.");

else if(id==0){
printf("My process id is %d\n", getpid());
//printf("The parent process id is: %d\n", getppid());
char *args[] = {"Hello", "C", "Programming", NULL};
    execv("./mycat", args);
    printf("Back to p3.c\n");
}

else{
wait();
printf("The parent  process id is %d\n", getpid());
//printf("The child  process id is: %d\n", fork());
}

return 0;
}
