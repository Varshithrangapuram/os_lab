#include<stdio.h>
#include<unistd.h>
#include<stdlib.h>
#include<string.h>
#include<fcntl.h>

void printcontent(const char *fname){
 FILE *file= fopen(fname, "r");
 char buf[256];
 while(fgets(buf, sizeof(buf), file)!= NULL){
	printf("%s", buf);
  }
  fclose(file);

}
int main(int argc, char* argv[])
{

const char *fname= argv[1];
int filed= open(fname,  O_WRONLY|O_CREAT|O_TRUNC, S_IWUSR| S_IRUSR);

if(filed==-1){
perror("Unable to open.");
return 1;
}

pid_t child_id= fork();

if(child_id==-1){
  printf("NOt forked");
return 1;
}

else if(child_id==0){
  printcontent(fname);
  exit(0);
}

else{
  wait();
//  const char* msg= "hello world i am the parent\n";
//  write(filed,msg, strlen(msg));
  int status;
  waitpid(child_id, &status, 0);
if(WIFEXITED(status))
  printf("Exited child process with status: %d.\n", child_id);
  printf("\ninside parent");
}
return 0;
}


