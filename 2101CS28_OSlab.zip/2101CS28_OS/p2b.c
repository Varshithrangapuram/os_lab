#include <stdio.h>
#include <stdlib.h>
#include <unistd.h>
#include <signal.h>
#include <sys/types.h>
#include <sys/wait.h>
#include <time.h>

// Function to generate a random sleep duration in milliseconds
int random_sleep() {
    return (rand() % 5000) + 5; // Sleep for a random time between 1 and 5 seconds
}

// Signal handler for SIGCHLD
void sigchld_handler(int signum) {
    int status;
    pid_t child_pid;

    while ((child_pid = waitpid(-1, &status, WNOHANG)) > 0) {
        if (WIFEXITED(status)) {
            printf("Child process with PID %d exited. \n", child_pid);
        } else {
            printf("Child process with PID %d terminated abnormally\n", child_pid);
        }
    }
}

int main(int argc, char *argv[]) {
    if (argc != 2) {
        fprintf(stderr, "Usage: %s <number_of_children>\n", argv[0]);
        return 1;
    }

    int n = atoi(argv[1]);

    if (n <= 0) {
        fprintf(stderr, "Invalid number of children. Please specify a positive integer.\n");
        return 1;
    }

    // Seed the random number generator
   // srand(time(NULL));

    // Override the SIGCHLD signal handler
    signal(SIGCHLD, sigchld_handler);

    // Spawn child processes
    for (int i = 0; i < n; i++) {
        pid_t child_pid = fork();
        srand(time(0));
        if (child_pid == 0) {
            // Child process

            int sleep_duration = random_sleep();
            printf("Child process with PID %d sleeping for %d milliseconds\n", getpid(), sleep_duration);
            usleep(sleep_duration * 1000); // Sleep in microseconds
            printf("Child process with PID %d exiting\n", getpid());
            exit(0);
        } else if (child_pid < 0) {
            // Fork failed
            perror("fork");
            return 1;
        }
    }

    // Parent process
   // while (1) {
        // Parent continues to run and wait for SIGCHLD signals
        sleep(25); // Sleep to avoid busy-waiting
   // }

    return 0;
}
