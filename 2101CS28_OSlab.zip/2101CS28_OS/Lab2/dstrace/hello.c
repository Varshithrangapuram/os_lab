#include<stdio.h>
using namespace std;

int main(){

printf("hello");

return 0;
}

