#include<bits/stdc++.h>
using namespace std;

int main(){

cout<<"Enter name:"<<endl;

string s;
getline(cin, s);
cout<<"Hi "<< s<<endl;

return 0;
}
