#include<bits/stdc++.h>
using namespace std;

int main(){

cout<<"Enter your Roll No."<<endl;
string s;
cin>>s;
return 0;
}
