#!/bin/bash

a=$1
b=$2

while [ $a -le $b ]
do
   echo $a
   let a++
done
