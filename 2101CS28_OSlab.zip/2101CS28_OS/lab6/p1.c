#include<stdio.h>
#include<stdlib.h>

void main(){
	printf("Enter no. of processes: ");
	int n; scanf("%d", &n);
	int bt[n], at[n], wt[n], tat[n];
	float awt=0, atat=0;
	printf("Enter arrival time: ");
	for(int i=0; i<n; i++){
		scanf("%d", &at[i]);
	}
	printf("Enter burst time: ");
	for(int i=0; i<n; i++){
		scanf("%d", &bt[i]);
	}
	for(int i=0; i<n; i++){
		wt[i]=0;
		tat[i]=0;

		for(int j=0; j<i; j++){
				wt[i] = wt[i]+ bt[j];
		}

		wt[i] = wt[i] - at[i];
		tat[i]= wt[i]+ bt[i];
		awt+= wt[i];
		atat+= tat[i];
	}

	awt = awt/n;
	atat = atat/n;
	printf("Waiting time of processes are:\n");
	for(int i=0; i<n; i++){
		printf("%d ", wt[i]);
	}
	printf("\n Turnaround time of processes are:\n");
	for(int i=0; i<n; i++){
		printf("%d ", tat[i]);
	}
	printf("\nAverage Waiting time: %f ", awt);
	printf("\n Average Turnaround time: %f\n", atat);
}

