#include <iostream>
#include <bits/stdc++.h>

using namespace std;

int main(){
        cout<<"Enter no. of processes: ";
        int n; cin>>n;
        int bt[n], at[n], wt[n]={0}, tat[n]={0};
        float awt=0, atat=0;
        cout<<("Enter arrival time: ");
        for(int i=0; i<n; i++){
                cin>>at[i];
        }
        cout<<("Enter burst time: ");
        for(int i=0; i<n; i++){
                cin>>bt[i];
        }

        bool vis[n]= {0};
        int time=0, cnt=0;
        vector<pair<int, int> > vec;

        while(cnt<n){
			vec.clear();
			for(int i=0; i<n; i++){
				if(at[i]<= time && !vis[i])
				vec.push_back({bt[i], i});
			}
			sort(vec.begin(), vec.end());
			pair<int, int> p1= vec[0];
			int id= p1.second;
			int btime= p1.first;
			wt[id] = (time-at[id]);
			tat[id] = wt[id]+btime;
			time+= btime;
			vis[id]=1; 
			cnt++;

			awt+= wt[id];
			atat += tat[id];
        }

        awt = awt/n;
        atat = atat/n;
        cout<<("Waiting time of processes are:\n");
        for(int i=0; i<n; i++){
            cout<<wt[i]<<" ";
        }
        cout<<("\nTurnaround time of processes are:\n");
        for(int i=0; i<n; i++){
            cout<<tat[i]<<" ";
        }
        cout<<"\nAverage Waiting time: "<<awt;
        cout<<"\nAverage Turnaround time: "<<atat<<endl;
}
