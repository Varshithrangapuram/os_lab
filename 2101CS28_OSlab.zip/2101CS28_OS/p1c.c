#include <stdio.h>
#include <stdlib.h>
#include <unistd.h>
#include <signal.h>
#include <sys/types.h>
#include <sys/wait.h>

// Signal handler for SIGCHLD
void sigchld_handler(int signum) {
    int status;
    pid_t child_pid;

    while ((child_pid = waitpid(-1, &status, WNOHANG)) > 0) {
        if (WIFEXITED(status)) {
            printf("Child process with PID %d exited with status %d\n", child_pid, WEXITSTATUS(status));
        } else {
            printf("Child process with PID %d terminated abnormally\n", child_pid);
        }
    }
}

int main() {
    signal(SIGCHLD, sigchld_handler);

    pid_t child_pid = fork();

    if (child_pid == 0) {
        // Child process
        printf("Child process (PID %d) is starting\n", getpid());

        pid_t grandchild_pid = fork();

        if (grandchild_pid == 0) {
            // Grandchild process
            printf("Grandchild process (PID %d) is starting\n", getpid());
            sleep(2); // Sleep for 2 seconds
            printf("Grandchild process (PID %d) is terminating\n", getpid());
            exit(0);
        } else if (grandchild_pid < 0) {
            perror("fork");
            exit(1);
        } else {
            // Child process
            sleep(5); // Sleep for 5 seconds
            printf("Child process (PID %d) is terminating\n", getpid());
            exit(0);
        }
    } else if (child_pid < 0) {
        perror("fork");
        exit(1);
    }

    // Parent process
    sleep(30);

    return 0;
}

